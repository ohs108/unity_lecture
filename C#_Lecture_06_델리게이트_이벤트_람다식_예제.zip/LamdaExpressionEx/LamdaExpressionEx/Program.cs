﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LamdaExpressionEx
{
    delegate int Operation(int a, int b);

    class Program
    {
        static void Main(string[] args)
        {
            Operation callback;
            
            // No Name Method
            callback = delegate(int a, int b) { return a + b; };
            Console.WriteLine(callback(8, 4));

            // Lamda Expression
            callback = (int a, int b) => a + b;
            Console.WriteLine(callback(8, 4));

            // Lamda Expression Multi Line
            callback = (int a, int b) =>
            {
                Console.Write("{0} + {1} = ", a, b);
                return a + b;
            };
            Console.WriteLine(callback(8,4));

            // Func Delegate
            Func<int, int, int> operation1 = delegate(int a, int b) { return a + b; };
            Console.WriteLine(operation1(8, 4));

            // Func Delegate Lamda Expression
            Func<int, int, int> operation2 = (int a, int b) => a + b;
            Console.WriteLine(operation2(8, 4));

            // Func Delegate Lamda Expression Multi Line
            Func<int, int, int> operation3 = (int a, int b) =>
            {
                Console.Write("{0} + {1} = ", a, b);
                return a + b;
            }; ;
            Console.WriteLine(operation3(8, 4));

            // Action Delegate Lamda Expression Multi Line
            Action<int, int> operation4 = delegate(int a, int b)
            {
                Console.Write("{0} + {1} = {2}", a, b, a + b);
            };
        }
    }
}
