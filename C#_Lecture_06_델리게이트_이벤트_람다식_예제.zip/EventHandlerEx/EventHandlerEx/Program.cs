﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHandlerEx
{
    delegate void EventHandler(string message);

    class A
    {
        public event EventHandler eventCB;

        public void generateEvent(int a, int b)
        {
            if (a % b == 0)
                eventCB(String.Format("{0} 은 {1} 로 나누어 떨어집니다.", a, b));
            else
                eventCB(String.Format("{0} 은 {1} 로 나누어 떨어지지 않습니다.", a, b));
        }
    }

    class Program
    {
        static public void MyHandler(string message)
        {
            Console.WriteLine(message);
        }

        static void Main(string[] args)
        {
            A aInst = new A();
            aInst.eventCB += new EventHandler(MyHandler);
            //aInst.eventCB("안녕하세요");

            for (int i = 0; i < 10; ++i)
            {
                aInst.generateEvent(i, 3);
            }
        }
    }
}
