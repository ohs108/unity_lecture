﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateEx
{
    delegate void Operation(int a, int b);

    class A
    {
        public void Plus(int a, int b)
        {
            Console.WriteLine("{0} + {1} = {2}", a, b, a + b);
        }

        public static void Minus(int a, int b)
        {
            Console.WriteLine("{0} - {1} = {2}", a, b, a - b);
        }
    }

    class Program
    {
        private static void Multiply(int a, int b)
        {
            Console.WriteLine("{0} * {1} = {2}", a, b, a * b);
        }

        static void Main(string[] args)
        {
            Operation callback;

            A aInstance = new A();
            callback = new Operation(aInstance.Plus);
            callback(8, 4);

            callback = new Operation(A.Minus);
            callback(8, 4);

            callback = new Operation(Multiply);
            callback(8, 4);

            Console.WriteLine("\n************ No Name Method ***************");
            callback =  delegate(int a, int b)
                        {
                            Console.WriteLine("{0} / {1} = {2}", a, b, a / b);
                        };
            callback(8, 4);

            // Delegate Chain
            Console.WriteLine("\n************ Delegate Chain 1 ***************");
            callback = Delegate.Combine(new Operation(aInstance.Plus),
                                        new Operation(A.Minus),
                                        new Operation(Multiply)) as Operation;
            callback(8, 4);

            Console.WriteLine("\n************ Delegate Chain 2 ***************");
            callback = new Operation(aInstance.Plus);
            callback += new Operation(A.Minus);
            callback += new Operation(Multiply);
            callback += delegate(int a, int b)
                        {
                            Console.WriteLine("{0} / {1} = {2}", a, b, a / b);
                        };
            callback(8, 4);

            Console.WriteLine("\n************ Delegate Chain 3 : Remove Chain ***************");
            callback -= new Operation(A.Minus);
            callback(8, 4);

            Console.WriteLine("\n************ Delegate Chain 4 : One Sentence ***************");
            callback = new Operation(aInstance.Plus) +
                        new Operation(A.Minus) +
                        new Operation(Multiply) +
                        delegate(int a, int b) { Console.WriteLine("{0} / {1} = {2}", a, b, a / b); };
            callback(8, 4);
        }
    }
}
